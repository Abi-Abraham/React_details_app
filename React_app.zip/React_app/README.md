# Getting Started with The APP

npm install

### `npm start`
