import "./App.css";
import TableData from "./components/TableData";

function App() {
  return (
    <div className="App">
      <TableData />
    </div>
  );
}

export default App;
