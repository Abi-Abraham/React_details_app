import React, { useState, useEffect } from "react";
import axios from "axios";

const TableData = () => {
  const [tableDetails, setTableDetails] = useState({});
  const [isFetch, setIsFetch] = useState(false);
  const [isDataSaved, setIsDataSaved] = useState(false);

  useEffect(() => {
    const fetchAPI = async () => {
      const options = {
        url: "https://randomuser.me/api",
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      };
      const res = await axios(options);
      if (200 >= res.status || res.status <= 300) {
        const {
          data: { results },
        } = res;
        const { email, name } = results[0];
        const data = {
          fullName: `${name.title} ${name.first} ${name.last}`,
          email,
        };
        localStorage.setItem("details", JSON.stringify(data));
        setIsDataSaved(true);
      }
    };
    fetchAPI();
  }, [isFetch]);

  useEffect(() => {
    const details = JSON.parse(localStorage.getItem("details"));
    setTableDetails(details);
    setIsDataSaved(false);
  }, [isDataSaved]);

  return (
    <div className="main">
      <button className="my-btn" onClick={() => setIsFetch(!isFetch)}>
        Refresh
      </button>
      {Object.keys(tableDetails).length ? (
        <div className="inner">
          <h3>{tableDetails?.fullName}</h3>
          <h3>{tableDetails?.email}</h3>
        </div>
      ) : (
        <h1>No data found</h1>
      )}
    </div>
  );
};

export default TableData;
